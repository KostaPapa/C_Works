#include <string>
#include <iostream>
#include "Rational.h"
using namespace std;

namespace CS1124{
	Rational::Rational():numerator(0), denominator(0){}
	ostream& operator<<(ostream& os, const Rational& num){
		os << num.numerator << "/" << num.denominator << endl;
		return os;
	}
	int Rational::greatestCommonDivisor(int x, int y){
		while (y != 0) {
			int temp = x % y;
			x = y;
			y = temp;
		}
		return x;
	}
	istream& operator>>(istream& is, Rational& num){
		char char1;
		is >> num.numerator; 
		is >> char1; 
		is >> num.denominator;
		int gcd = num.greatestCommonDivisor(num.numerator, num.denominator);
		if(num.denominator < 0){
			num.numerator = ((-1*num.numerator)/gcd);
			num.denominator = ((-1*num.denominator)/gcd);
		}
		else{
			num.numerator = num.numerator/gcd;
			num.denominator = num.denominator/gcd;
		}
		return is;
	}
	Rational& Rational::operator+=(Rational& num){
		numerator += num.numerator;
		denominator += num.denominator;
		return *this;
	}
	Rational operator +(const Rational& lhs, Rational& rhs){
		Rational result = lhs;
		result += rhs;
		return result;
	}
	Rational operator !=(const Rational& lhs, Rational& rhs){
	}
	Rational operator ++(Rational& numerator){
		++numerator;
		return *this;
	}
	Rational operator --(const Rational& lhs, Rational& rhs){
	}
}