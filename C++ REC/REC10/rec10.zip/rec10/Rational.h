#ifndef RATIONAL_H
#define RATIONAL_H
#include <string>

namespace CS1124{
	class Rational{
		friend std::ostream& operator <<(std::ostream& os, const Rational& num);
		friend std::istream& operator >>(std::istream& is, Rational& num);
	public:
		Rational();
		int greatestCommonDivisor(int x, int y);
		Rational& operator +=(Rational& num);
	private:
		int numerator;
		int denominator;
	};
}
#endif